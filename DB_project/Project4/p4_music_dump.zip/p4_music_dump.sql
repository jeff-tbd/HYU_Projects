-- MySQL dump 10.16  Distrib 10.2.9-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: musicapp
-- ------------------------------------------------------
-- Server version	10.2.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `album`
--

DROP TABLE IF EXISTS `album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album` (
  `ANUMBER` int(11) NOT NULL,
  `ANAME` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ANUMBER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album`
--

LOCK TABLES `album` WRITE;
/*!40000 ALTER TABLE `album` DISABLE KEYS */;
INSERT INTO `album` VALUES (1,'ALBUM1'),(2,'ALBUM2'),(3,'ALBUM3'),(4,'album4');
/*!40000 ALTER TABLE `album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chart`
--

DROP TABLE IF EXISTS `chart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chart` (
  `CNAME` varchar(15) NOT NULL,
  `COUNTRY` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`CNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chart`
--

LOCK TABLES `chart` WRITE;
/*!40000 ALTER TABLE `chart` DISABLE KEYS */;
INSERT INTO `chart` VALUES ('BILLBOARD','USA'),('BUGS','KOREA'),('MELON','KOREA');
/*!40000 ALTER TABLE `chart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `madeby`
--

DROP TABLE IF EXISTS `madeby`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `madeby` (
  `MNUM` int(11) NOT NULL,
  `SNM` varchar(15) NOT NULL,
  `SNO` int(11) NOT NULL,
  PRIMARY KEY (`MNUM`,`SNM`,`SNO`),
  KEY `MADEBYFK2` (`SNO`,`SNM`),
  CONSTRAINT `MADEBYFK` FOREIGN KEY (`MNUM`) REFERENCES `music` (`MNUMBER`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `MADEBYFK2` FOREIGN KEY (`SNO`, `SNM`) REFERENCES `singer` (`SNUMBER`, `SNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `madeby`
--

LOCK TABLES `madeby` WRITE;
/*!40000 ALTER TABLE `madeby` DISABLE KEYS */;
INSERT INTO `madeby` VALUES (1,'BUMSU',1),(1,'SOULKING',1),(2,'MOONMOON',1),(3,'SOULKING',1),(4,'BUMSU',1),(5,'BUMSU',2);
/*!40000 ALTER TABLE `madeby` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `makeclist`
--

DROP TABLE IF EXISTS `makeclist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `makeclist` (
  `MNUM` int(11) NOT NULL,
  `CNM` varchar(15) NOT NULL,
  `RANK` int(11) DEFAULT NULL,
  PRIMARY KEY (`MNUM`,`CNM`),
  KEY `CLISTFK2` (`CNM`),
  CONSTRAINT `CLISTFK` FOREIGN KEY (`MNUM`) REFERENCES `music` (`MNUMBER`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CLISTFK2` FOREIGN KEY (`CNM`) REFERENCES `chart` (`CNAME`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `makeclist`
--

LOCK TABLES `makeclist` WRITE;
/*!40000 ALTER TABLE `makeclist` DISABLE KEYS */;
INSERT INTO `makeclist` VALUES (1,'BILLBOARD',1),(1,'MELON',4),(2,'BILLBOARD',2),(2,'MELON',2),(3,'BILLBOARD',7),(3,'BUGS',10),(5,'BILLBOARD',8);
/*!40000 ALTER TABLE `makeclist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `makeplist`
--

DROP TABLE IF EXISTS `makeplist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `makeplist` (
  `PNO` int(11) NOT NULL,
  `UNO` int(11) NOT NULL,
  `MNUM` int(11) NOT NULL,
  PRIMARY KEY (`PNO`,`UNO`,`MNUM`),
  KEY `PLISTFK2` (`MNUM`),
  CONSTRAINT `PLISTFK` FOREIGN KEY (`PNO`, `UNO`) REFERENCES `playlist` (`PNUMBER`, `UNO`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `PLISTFK2` FOREIGN KEY (`MNUM`) REFERENCES `music` (`MNUMBER`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `makeplist`
--

LOCK TABLES `makeplist` WRITE;
/*!40000 ALTER TABLE `makeplist` DISABLE KEYS */;
INSERT INTO `makeplist` VALUES (1,1,1),(1,2,5),(2,1,3);
/*!40000 ALTER TABLE `makeplist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manager`
--

DROP TABLE IF EXISTS `manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manager` (
  `MNUMBER` int(11) NOT NULL,
  `PW` varchar(20) NOT NULL,
  PRIMARY KEY (`MNUMBER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manager`
--

LOCK TABLES `manager` WRITE;
/*!40000 ALTER TABLE `manager` DISABLE KEYS */;
INSERT INTO `manager` VALUES (1,'MANAGER1'),(2,'MANAGER2'),(3,'MANAGER3');
/*!40000 ALTER TABLE `manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mgenre`
--

DROP TABLE IF EXISTS `mgenre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mgenre` (
  `MNUM` int(11) NOT NULL,
  `GENRE` varchar(10) NOT NULL,
  PRIMARY KEY (`MNUM`,`GENRE`),
  CONSTRAINT `GENREFK` FOREIGN KEY (`MNUM`) REFERENCES `music` (`MNUMBER`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mgenre`
--

LOCK TABLES `mgenre` WRITE;
/*!40000 ALTER TABLE `mgenre` DISABLE KEYS */;
INSERT INTO `mgenre` VALUES (1,'BALLAD'),(1,'POP'),(2,'HIPHOP'),(3,'JAZZ'),(4,'COUNTRY'),(5,'COUNTRY');
/*!40000 ALTER TABLE `mgenre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `music`
--

DROP TABLE IF EXISTS `music`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `music` (
  `MNUMBER` int(11) NOT NULL,
  `NAME` varchar(15) DEFAULT NULL,
  `PLAYTIME` time DEFAULT NULL,
  `ANO` int(11) NOT NULL,
  `MANUM` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`MNUMBER`),
  KEY `MUSICALFK` (`ANO`),
  KEY `MUSICMAFK` (`MANUM`),
  CONSTRAINT `MUSICALFK` FOREIGN KEY (`ANO`) REFERENCES `album` (`ANUMBER`) ON DELETE CASCADE,
  CONSTRAINT `MUSICMAFK` FOREIGN KEY (`MANUM`) REFERENCES `manager` (`MNUMBER`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `music`
--

LOCK TABLES `music` WRITE;
/*!40000 ALTER TABLE `music` DISABLE KEYS */;
INSERT INTO `music` VALUES (1,'MUSIC1','03:20:00',1,1),(2,'MUSIC2','04:01:00',2,1),(3,'MUSIC3','02:50:00',2,1),(4,'MUSIC4','03:15:00',4,1),(5,'MUSIC5','02:20:00',3,3);
/*!40000 ALTER TABLE `music` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `playlist`
--

DROP TABLE IF EXISTS `playlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `playlist` (
  `PNUMBER` int(11) NOT NULL DEFAULT 1,
  `NAME` varchar(15) DEFAULT 'PLAYLIST',
  `UNO` int(11) NOT NULL,
  PRIMARY KEY (`PNUMBER`,`UNO`),
  KEY `PLAYLISTFK` (`UNO`),
  CONSTRAINT `PLAYLISTFK` FOREIGN KEY (`UNO`) REFERENCES `user` (`UNUMBER`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playlist`
--

LOCK TABLES `playlist` WRITE;
/*!40000 ALTER TABLE `playlist` DISABLE KEYS */;
INSERT INTO `playlist` VALUES (1,'HAPPY',1),(1,'CHEERUP',2),(2,'HOT',1);
/*!40000 ALTER TABLE `playlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `singer`
--

DROP TABLE IF EXISTS `singer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `singer` (
  `SNUMBER` int(11) NOT NULL DEFAULT 1,
  `SNAME` varchar(15) NOT NULL,
  PRIMARY KEY (`SNUMBER`,`SNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `singer`
--

LOCK TABLES `singer` WRITE;
/*!40000 ALTER TABLE `singer` DISABLE KEYS */;
INSERT INTO `singer` VALUES (1,'BUMSU'),(1,'MOONMOON'),(1,'SOULKING'),(1,'TAEYEON'),(2,'BUMSU');
/*!40000 ALTER TABLE `singer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `UNUMBER` int(11) NOT NULL,
  `ID` varchar(20) NOT NULL,
  `PW` varchar(20) DEFAULT 'PW',
  `LEVEL` int(11) DEFAULT 1,
  `NAME` varchar(15) DEFAULT 'USER',
  `EMAIL` varchar(25) DEFAULT NULL,
  `PHONE` char(11) DEFAULT NULL,
  `SDATE` date DEFAULT NULL,
  `MNO` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`UNUMBER`),
  KEY `USERFK` (`MNO`),
  CONSTRAINT `USERFK` FOREIGN KEY (`MNO`) REFERENCES `manager` (`MNUMBER`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'ID1','PW1',1,'HAN1','hanman2@hanyang.ac.kr','01012345678','2017-11-01',1),(2,'ID2','PW2',1,'HAN2','HAN2@HANYANG.AC.KR','01012345670','2017-11-02',2),(3,'ID3','PW3',2,'HAN3','HAN3@HANYANG.AC.KR','01012345672','2017-11-20',3);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-08 14:24:16
